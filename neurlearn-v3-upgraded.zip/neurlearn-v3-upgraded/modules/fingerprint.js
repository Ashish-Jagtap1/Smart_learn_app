// ── Speed Fingerprint Module (v2 — upgraded) ──────────────────
// Ported from fingerprint.py with full logic.
// Groups: content_type, time_of_day, energy_level, task_type
// Score: 5s = 100pts, 30s = 0pts (linear)

const timeToScore = (avgTime) => {
  if (avgTime <= 5)  return 100.0;
  if (avgTime >= 30) return 0.0;
  return Math.round(100 * (1 - (avgTime - 5) / 25) * 10) / 10;
};

const getTimeOfDay = (timestamp) => {
  const hour = timestamp ? new Date(timestamp).getHours() : new Date().getHours();
  if (hour >= 5  && hour < 12) return 'morning';
  if (hour >= 12 && hour < 18) return 'afternoon';
  return 'evening';
};

const calculateFingerprint = (responses) => {
  if (!responses || responses.length < 5) {
    return { message: `Need at least 5 answers (have ${responses ? responses.length : 0})`, data_points: responses ? responses.length : 0, ready: false };
  }

  const groups = {};

  responses.forEach(r => {
    const time = r.response_time || 15;
    const addTo = (key) => { if (!groups[key]) groups[key] = []; groups[key].push(time); };

    // Content type
    addTo(r.content_type || 'textual');
    // Time of day
    addTo(getTimeOfDay(r.timestamp));
    // Energy level
    const diff = r.difficulty || 5;
    addTo(diff >= 7 ? 'high_energy' : diff >= 4 ? 'medium_energy' : 'low_energy');
    // Task type
    addTo(diff <= 3 ? 'recall' : diff <= 6 ? 'application' : 'problem_solving');
  });

  const result = {};
  for (const [key, times] of Object.entries(groups)) {
    if (times.length >= 3) {
      result[key] = timeToScore(times.reduce((a, b) => a + b, 0) / times.length);
    }
  }

  const allTimes = responses.map(r => r.response_time || 15);
  const overallAvg = allTimes.reduce((a, b) => a + b, 0) / allTimes.length;
  result.overall = timeToScore(overallAvg);
  result.overall_avg_seconds = Math.round(overallAvg * 10) / 10;

  const peak = Object.entries(result)
    .filter(([k]) => !['overall', 'overall_avg_seconds'].includes(k))
    .reduce((a, b) => a[1] > b[1] ? a : b, ['none', 0])[0];

  return { ...result, data_points: responses.length, ready: true, peak_condition: peak };
};

const getInsights = (fp) => {
  if (!fp.ready) return [fp.message || 'Not enough data yet.'];
  const insights = [];
  if (fp.visual !== undefined && fp.textual !== undefined) {
    const d = fp.visual - fp.textual;
    if (d >= 15)  insights.push(`You learn ${Math.round(d)}% faster with visual content. Ask for diagrams whenever possible.`);
    if (d <= -15) insights.push(`You learn ${Math.round(Math.abs(d))}% faster with text. Reading-based study suits you best.`);
  }
  if (fp.morning !== undefined && fp.evening !== undefined && fp.morning - fp.evening >= 10)
    insights.push(`You are ${Math.round(fp.morning - fp.evening)} points faster in the morning. Schedule hard topics early.`);
  if (fp.high_energy !== undefined && fp.low_energy !== undefined && fp.high_energy - fp.low_energy >= 15)
    insights.push(`Your speed drops ${Math.round(fp.high_energy - fp.low_energy)} points when energy is low. Take breaks every 40 minutes.`);
  if (fp.recall !== undefined && fp.problem_solving !== undefined && fp.recall - fp.problem_solving >= 15)
    insights.push(`You are much faster at recall than problem solving. Practise more applied problems.`);
  if (insights.length === 0)
    insights.push(`Overall speed score: ${fp.overall}/100. Keep answering to unlock more insights.`);
  return insights;
};

module.exports = { calculateFingerprint, getInsights };
