// ── Counterfactual Coach Module (v2 — upgraded) ────────────────
// Ported from coach.py with full lookup table logic.
//
// Instead of generic advice, shows EXACTLY how much faster
// you'd be if you changed something right now.
// "Take a break NOW → 28% faster for 30 minutes"

// Speed lookup table: (time_of_day, energy) → avg seconds per question
const SPEED_LOOKUP = {
  'morning-high':    10,
  'morning-medium':  13,
  'morning-low':     16,
  'afternoon-high':  12,
  'afternoon-medium':15,
  'afternoon-low':   18,
  'evening-high':    15,
  'evening-medium':  18,
  'evening-low':     22,
};

const getTimeOfDay = () => {
  const hour = new Date().getHours();
  if (hour >= 5  && hour < 12) return 'morning';
  if (hour >= 12 && hour < 18) return 'afternoon';
  return 'evening';
};

const budgetToEnergy = (budget) => {
  if (budget >= 70) return 'high';
  if (budget >= 40) return 'medium';
  return 'low';
};

const getCurrentSpeed = (timeOfDay, budget) => {
  const energy = budgetToEnergy(budget);
  return SPEED_LOOKUP[`${timeOfDay}-${energy}`] || 17;
};

const calcImprovement = (currentSpeed, predictedSpeed) => {
  if (currentSpeed <= 0) return 0;
  const improvement = ((currentSpeed - predictedSpeed) / currentSpeed) * 100;
  return Math.round(Math.min(improvement, 50)); // cap at 50%
};

const generateSuggestions = ({ budget, cvState, minutesSinceBreak, responses }) => {
  const suggestions = [];
  const timeOfDay   = getTimeOfDay();
  const energy      = budgetToEnergy(budget);
  const currentSpeed = getCurrentSpeed(timeOfDay, budget);

  // ── Suggestion 1: Take a break ──────────────────────────
  if (minutesSinceBreak >= 20 || budget < 60 || cvState === 'TIRED' || cvState === 'SLEEPING') {
    const afterBreakSpeed = SPEED_LOOKUP[`${timeOfDay}-high`] || 12;
    const improvement     = calcImprovement(currentSpeed, afterBreakSpeed);
    if (improvement > 5) {
      suggestions.push({
        type:        'break',
        icon:        '☕',
        action:      'Take a 5-min break now',
        suggestion:  `Take a 5-minute break right now. Your speed will go from ${currentSpeed}s to ~${afterBreakSpeed}s per question — that's ${improvement}% faster for the next 30 minutes.`,
        benefit:     `${improvement}% faster for next 30 mins`,
        improvement,
        priority:    1,
      });
    }
  }

  // ── Suggestion 2: Best study time ───────────────────────
  const bestSpeed      = SPEED_LOOKUP['morning-high'];
  const bestImprovement = calcImprovement(currentSpeed, bestSpeed);
  if (!(timeOfDay === 'morning' && energy === 'high') && bestImprovement > 5) {
    suggestions.push({
      type:        'timing',
      icon:        '🌅',
      action:      'Study tomorrow morning instead',
      suggestion:  `Study at 9am tomorrow when your energy is fresh. You'd go from ${currentSpeed}s to ~${bestSpeed}s per question — that's ${bestImprovement}% faster overall.`,
      benefit:     `${bestImprovement}% faster in morning`,
      improvement: bestImprovement,
      priority:    2,
    });
  } else if (timeOfDay === 'morning' && energy === 'high') {
    suggestions.push({
      type:        'timing',
      icon:        '⚡',
      action:      'You are in peak learning window!',
      suggestion:  'You are in your best learning window — morning + high energy. Keep going!',
      benefit:     'Best time to tackle hard concepts',
      improvement: 0,
      priority:    2,
    });
  }

  // ── Suggestion 3: Switch to easier content ───────────────
  if (cvState === 'FRUSTRATED' || budget < 30) {
    const easierSpeed   = Math.max(currentSpeed - 4, 6);
    const easyImprovement = calcImprovement(currentSpeed, easierSpeed);
    if (easyImprovement > 5) {
      suggestions.push({
        type:        'difficulty',
        icon:        '📖',
        action:      'Switch to easier review content',
        suggestion:  `Switch to easier review material for 20 minutes. You'd go from ${currentSpeed}s to ~${easierSpeed}s per question — that's ${easyImprovement}% faster right now.`,
        benefit:     `${easyImprovement}% faster with easier content`,
        improvement: easyImprovement,
        priority:    3,
      });
    }
  } else if (budget > 80 && cvState === 'FOCUSED') {
    suggestions.push({
      type:        'difficulty',
      icon:        '🎯',
      action:      'Try harder questions — you are focused!',
      suggestion:  'Your budget is high and you are focused. Best time to tackle difficult concepts.',
      benefit:     'Best time for hard questions',
      improvement: 0,
      priority:    3,
    });
  }

  // ── Suggestion 4: Stop if late + tired ───────────────────
  if (timeOfDay === 'evening' && budget < 40) {
    const stopImprovement = calcImprovement(currentSpeed, bestSpeed);
    suggestions.push({
      type:        'stop',
      icon:        '🛑',
      action:      'Stop and resume tomorrow morning',
      suggestion:  `You are studying late with low energy (${budget}% budget). Stopping now and resuming fresh tomorrow morning would make you ${stopImprovement}% faster.`,
      benefit:     `${stopImprovement}% faster tomorrow morning`,
      improvement: stopImprovement,
      priority:    1,
    });
  }

  // ── CV-specific ───────────────────────────────────────────
  if (cvState === 'DISTRACTED') {
    suggestions.push({ type: 'focus', icon: '👀', action: 'Refocus!', suggestion: 'Distraction detected — close other tabs and minimize distractions.', benefit: '25% faster when focused', improvement: 25, priority: 1 });
  }

  // Sort by improvement descending, then priority
  return suggestions.sort((a, b) => b.improvement - a.improvement || a.priority - b.priority);
};

module.exports = { generateSuggestions };
