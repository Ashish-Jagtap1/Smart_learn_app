// ── Difficulty Engine ──────────────────────────────────────────
// Adapts question difficulty based on performance + CV state.
//
// Rules:
//   2 correct in a row  → difficulty + 1 (max 10)
//   2 wrong in a row    → difficulty - 1 (min 1)
//   TIRED/SLEEPING/FRUSTRATED → force difficulty - 1
//   Starts at 5/10

const difficulties = {};  // { sessionId: difficultyValue }
const streaks      = {};  // { sessionId: { correct, wrong } }

/**
 * Get current difficulty (defaults to 5)
 */
const getDifficulty = (sessionId) => {
  if (difficulties[sessionId] === undefined) difficulties[sessionId] = 5;
  return difficulties[sessionId];
};

/**
 * Update difficulty after each answer
 * @param {string}  sessionId
 * @param {boolean} isCorrect
 * @param {string}  cvState   - current CV state from Person 1
 */
const updateDifficulty = (sessionId, isCorrect, cvState = 'FOCUSED') => {
  const current = getDifficulty(sessionId);

  if (!streaks[sessionId]) {
    streaks[sessionId] = { correct: 0, wrong: 0 };
  }

  // Update streak
  if (isCorrect) {
    streaks[sessionId].correct += 1;
    streaks[sessionId].wrong    = 0;
  } else {
    streaks[sessionId].wrong   += 1;
    streaks[sessionId].correct  = 0;
  }

  let newDiff = current;

  // Performance adaptation
  if (streaks[sessionId].correct >= 2) {
    newDiff = Math.min(10, current + 1);
    streaks[sessionId].correct = 0; // reset streak counter
  }
  if (streaks[sessionId].wrong >= 2) {
    newDiff = Math.max(1, current - 1);
    streaks[sessionId].wrong = 0;
  }

  // CV state OVERRIDES performance (priority)
  if (['TIRED', 'SLEEPING', 'FRUSTRATED'].includes(cvState)) {
    newDiff = Math.max(1, newDiff - 1);
  }

  difficulties[sessionId] = newDiff;
  return newDiff;
};

/**
 * Reset difficulty for new session
 */
const resetDifficulty = (sessionId) => {
  difficulties[sessionId] = 5;
  streaks[sessionId]       = { correct: 0, wrong: 0 };
  return 5;
};

/**
 * Get current streak info
 */
const getStreak = (sessionId) => streaks[sessionId] || { correct: 0, wrong: 0 };

module.exports = { getDifficulty, updateDifficulty, resetDifficulty, getStreak };
