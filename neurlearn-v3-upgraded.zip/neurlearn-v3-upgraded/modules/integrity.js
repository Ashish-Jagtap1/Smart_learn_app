// ── Integrity / Anti-Gaming Module (v2 — upgraded) ────────────
// Ported from integrity.py with full detection logic.
//
// Checks:
//   1. Impossible speed — answered too fast for difficulty level
//   2. Random guessing  — alternating correct/wrong 7+ times in 10
//   3. Tab switch / paste / copy / right_click (frontend reported)
//
// Score starts at 100, deducts on violations.
// Score < 70 → verification_needed = true

// Expected time per difficulty level (seconds) — from Python
const EXPECTED_TIMES = {
  easy:   10,   // difficulty 1-3
  medium: 18,   // difficulty 4-7
  hard:   25,   // difficulty 8-10
};

const getDifficultyLabel = (difficulty) => {
  if (difficulty <= 3) return 'easy';
  if (difficulty <= 7) return 'medium';
  return 'hard';
};

const integrityStore = {}; // { sessionId: { score, flags } }

const getIntegrity = (sessionId) => {
  if (!integrityStore[sessionId]) {
    integrityStore[sessionId] = { score: 100, flags: [] };
  }
  return integrityStore[sessionId];
};

/**
 * Check integrity after each answer submission
 */
const checkIntegrity = (sessionId, answer, recentAnswers = []) => {
  const state    = getIntegrity(sessionId);
  const newFlags = [];

  // ── Check 1: Impossible speed ────────────────────────────
  // Answered correctly AND under 30% of expected time for difficulty
  const label     = getDifficultyLabel(answer.difficulty || 5);
  const expected  = EXPECTED_TIMES[label];
  const threshold = expected * 0.3; // 30% threshold (from Python)

  if (answer.is_correct && (answer.response_time || 99) < threshold) {
    const reason = `Impossible speed: answered ${label} question in ${answer.response_time}s (expected ~${expected}s, threshold ${Math.round(threshold * 10) / 10}s) and got it correct.`;
    newFlags.push({ type: 'IMPOSSIBLE_SPEED', severity: 'HIGH', reason, deduction: 30 });
    state.score = Math.max(0, state.score - 30);
  }

  // ── Check 2: Random guessing pattern ─────────────────────
  // More than 7 switches in last 10 answers
  if (recentAnswers.length >= 10) {
    let switches = 0;
    for (let i = 1; i < recentAnswers.length; i++) {
      if (recentAnswers[i].is_correct !== recentAnswers[i - 1].is_correct) switches++;
    }
    if (switches >= 7) {
      const reason = `Random guessing pattern: ${switches} correct/wrong switches in last 10 answers. Normal learners show 3-4 switches.`;
      newFlags.push({ type: 'RANDOM_GUESSING', severity: 'LOW', reason, deduction: 5 });
      state.score = Math.max(0, state.score - 5);
    }
  }

  state.flags.push(...newFlags);

  // Summary message
  let summary;
  if (state.score >= 90)     summary = 'All good. No suspicious patterns detected.';
  else if (state.score >= 70) summary = 'Minor flags detected. Monitoring closely.';
  else                        summary = 'Suspicious activity detected. Verification round triggered.';

  return {
    integrity_score:     state.score,
    new_flags:           newFlags,
    all_flags:           state.flags,
    verification_needed: state.score < 70,
    summary,
  };
};

/**
 * Record frontend-reported events (tab switch, paste, etc.)
 */
const recordEvent = (sessionId, eventType, details = '') => {
  const state = getIntegrity(sessionId);

  const deductions = {
    tab_switch:  10,
    paste:       15,
    copy:         5,
    right_click:  5,
  };

  const deduction = deductions[eventType] || 5;
  state.score = Math.max(0, state.score - deduction);
  state.flags.push({ type: eventType.toUpperCase(), severity: 'MEDIUM', reason: `${eventType} detected. Details: ${details}`, deduction });

  console.log(`⚠️  Integrity event: ${eventType} | session: ${sessionId} | score: ${state.score}`);

  let summary;
  if (state.score >= 90)     summary = 'All good.';
  else if (state.score >= 70) summary = 'Minor flags detected.';
  else                        summary = 'Suspicious activity detected. Verification triggered.';

  return {
    integrity_score:     state.score,
    event_recorded:      eventType,
    verification_needed: state.score < 70,
    summary,
  };
};

const resetIntegrity = (sessionId) => {
  integrityStore[sessionId] = { score: 100, flags: [] };
};

module.exports = { getIntegrity, checkIntegrity, recordEvent, resetIntegrity };
