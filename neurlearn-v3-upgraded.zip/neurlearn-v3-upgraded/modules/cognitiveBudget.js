// ── Cognitive Budget Module ────────────────────────────────────
// Tracks mental energy (0-100) per session.
// Called every 5 seconds when CV engine sends state.
//
// Depletion rates (per 5-second tick):
//   FOCUSED:    -0.125  (loses 1.5 per minute)
//   TIRED:      -1.25   (loses 15 per minute)
//   FRUSTRATED: -0.83   (loses 10 per minute)
//   DISTRACTED:  0      (paused — not actively learning)
//   SLEEPING:    0      (paused)
//
// Budget → Difficulty mapping:
//   80-100 → difficulty 8  (student is fresh, challenge them)
//   50-79  → difficulty 5  (moderate)
//   20-49  → difficulty 3  (getting tired, ease up)
//   0-19   → difficulty 1  (very tired, very easy)

const DEPLETION_RATES = {
  FOCUSED:    0.125,
  TIRED:      1.25,
  FRUSTRATED: 0.83,
  DISTRACTED: 0,
  SLEEPING:   0,
};

// In-memory store: { sessionId: budgetValue }
const budgets = {};

/**
 * Get current budget (defaults to 100 for new sessions)
 */
const getBudget = (sessionId) => {
  if (budgets[sessionId] === undefined) budgets[sessionId] = 100;
  return budgets[sessionId];
};

/**
 * Deplete budget based on CV state
 * Called every 5 seconds by /api/cv/state
 */
const depleteBudget = (sessionId, cvState) => {
  const current = getBudget(sessionId);
  const rate    = DEPLETION_RATES[cvState] ?? 0.125;
  const updated = Math.max(0, parseFloat((current - rate).toFixed(3)));
  budgets[sessionId] = updated;
  return updated;
};

/**
 * Map budget to difficulty level (1-10)
 */
const getDifficultyFromBudget = (budget) => {
  if (budget >= 80) return 8;
  if (budget >= 50) return 5;
  if (budget >= 20) return 3;
  return 1;
};

/**
 * Reset budget to 100 for a new session
 */
const resetBudget = (sessionId) => {
  budgets[sessionId] = 100;
  return 100;
};

/**
 * Get all active session budgets (for debugging)
 */
const getAllBudgets = () => ({ ...budgets });

module.exports = {
  getBudget,
  depleteBudget,
  getDifficultyFromBudget,
  resetBudget,
  getAllBudgets,
};
