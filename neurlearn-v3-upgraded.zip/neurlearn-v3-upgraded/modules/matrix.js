// ── Confidence Matrix Module (v2 — upgraded) ──────────────────
// Ported from matrix.py with full logic.
//
// Calibration error = avg |confidence - actual_outcome|
// actual_outcome = 100 if correct, 0 if wrong
//
// Quadrants (speed threshold=15s, calibration threshold=30%):
//   Fast + Well Calibrated  → Ideal Learner      🚀
//   Fast + Overconfident    → Speed Guesser       ⚠️
//   Slow + Well Calibrated  → Careful Thinker     🔵
//   Slow + Overconfident    → Struggling Learner  🔴

const calculateMatrix = (responses) => {
  if (!responses || responses.length < 5) {
    return { message: `Need at least 5 answers (have ${responses ? responses.length : 0})`, data_points: responses ? responses.length : 0, ready: false };
  }

  // Average response time
  const avgTime = responses.reduce((s, r) => s + (r.response_time || 15), 0) / responses.length;

  // Calibration error
  const totalError = responses.reduce((s, r) => {
    const actual = r.is_correct ? 100 : 0;
    return s + Math.abs((r.confidence || 50) - actual);
  }, 0);
  const calibrationError = totalError / responses.length;

  // Accuracy
  const correct  = responses.filter(r => r.is_correct).length;
  const accuracy = Math.round((correct / responses.length) * 100);

  // Avg confidence
  const avgConfidence = Math.round(responses.reduce((s, r) => s + (r.confidence || 50), 0) / responses.length);

  const isFast       = avgTime < 15;
  const isCalibrated = calibrationError < 30;

  // Quadrant classification (matching Python logic exactly)
  let quadrant, strategy, emoji, quadrantLabel;

  if (isFast && isCalibrated) {
    quadrant      = 'Fast + Well Calibrated';
    quadrantLabel = 'Ideal Learner';
    strategy      = 'Accelerate! Give harder content and faster pacing.';
    emoji         = '🚀';
  } else if (isFast && !isCalibrated) {
    quadrant      = 'Fast + Overconfident';
    quadrantLabel = 'Speed Guesser';
    strategy      = 'Challenge with tricky edge-case questions to expose gaps.';
    emoji         = '⚠️';
  } else if (!isFast && isCalibrated) {
    quadrant      = 'Slow + Well Calibrated';
    quadrantLabel = 'Careful Thinker';
    strategy      = 'Provide hints, worked examples and celebrate small wins.';
    emoji         = '🔵';
  } else {
    quadrant      = 'Slow + Overconfident';
    quadrantLabel = 'Struggling Learner';
    strategy      = 'Show the gap between perceived and actual performance.';
    emoji         = '🔴';
  }

  return {
    quadrant,
    quadrant_label:    quadrantLabel,
    emoji,
    strategy,
    avg_time:          Math.round(avgTime * 10) / 10,
    calibration_error: Math.round(calibrationError),
    avg_confidence:    avgConfidence,
    actual_accuracy:   accuracy,
    is_fast:           isFast,
    is_calibrated:     isCalibrated,
    data_points:       responses.length,
    ready:             true,
  };
};

module.exports = { calculateMatrix };
