// ═══════════════════════════════════════════════════════════
//  NeurLearn Backend — v3.0
//  Speed-adaptive EdTech platform
//  Person 2: Backend Developer
// ═══════════════════════════════════════════════════════════

require('dotenv').config();
const express = require('express');
const cors    = require('cors');

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Middleware ───────────────────────────────────────────────
app.use(cors({ origin: '*', methods: ['GET', 'POST'], allowedHeaders: ['Content-Type'] }));
app.use(express.json());

// ── Routes ───────────────────────────────────────────────────
app.use('/api/questions',  require('./routes/questions'));
app.use('/api/answer',     require('./routes/answers'));
app.use('/api/cv',         require('./routes/cvState'));
app.use('/api/status',     require('./routes/status'));
app.use('/api/session',    require('./routes/session'));
app.use('/api/integrity',  require('./routes/integrity'));

// ── Health check ─────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    app:     'NeurLearn Backend',
    version: '3.0.0',
    status:  'running',
    time:    new Date().toISOString(),
    routes: {
      'POST /api/questions':         'Generate MCQ questions (Groq AI)',
      'POST /api/answer':            'Submit answer + update difficulty',
      'POST /api/cv/state':          'Receive CV state from CV engine (every 5s)',
      'GET  /api/cv/history':        'Get CV state history',
      'GET  /api/status':            'Get all dashboard metrics',
      'GET  /api/status/fingerprint':'Speed fingerprint radar data',
      'GET  /api/status/matrix':     'Confidence matrix quadrant',
      'GET  /api/status/suggestions':'Coaching suggestions',
      'POST /api/session/start':     'Start new learning session',
      'POST /api/session/end':       'End session + save summary',
      'GET  /api/session/history':   'All past sessions',
      'POST /api/integrity/event':   'Report tab switch / paste event',
      'GET  /api/integrity/score':   'Get integrity score',
    }
  });
});

// ── Global error handler ─────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌ Unhandled error:', err.message);
  res.status(500).json({ error: 'Internal server error', message: err.message });
});

// ── Catch unhandled promise rejections ───────────────────────
process.on('unhandledRejection', (reason) => {
  console.error('⚠️  Unhandled rejection:', reason);
});

// ── Start server ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('═══════════════════════════════════════');
  console.log('  NeurLearn Backend v3.0');
  console.log(`  http://localhost:${PORT}`);
  console.log('═══════════════════════════════════════');
});
