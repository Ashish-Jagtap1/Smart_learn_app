// ── Database Setup ────────────────────────────────────────────
// SQLite with 4 tables:
//   sessions   — one row per learning session
//   responses  — every answer submitted
//   cv_states  — every CV reading from Person 1 (every 5s)
//   integrity_events — tab switches, pastes detected

const sqlite3 = require('sqlite3').verbose();
const path    = require('path');

const db = new sqlite3.Database(path.join(__dirname, '../app.db'), (err) => {
  if (err) {
    console.error('❌ Database error:', err.message);
    process.exit(1);
  }
  console.log('✅ Database connected');
});

db.serialize(() => {

  // ── Sessions ─────────────────────────────────────────────
  db.run(`CREATE TABLE IF NOT EXISTS sessions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT    UNIQUE,
    topic           TEXT    DEFAULT 'General',
    start_time      TEXT    DEFAULT (datetime('now')),
    end_time        TEXT,
    total_questions INTEGER DEFAULT 0,
    correct_answers INTEGER DEFAULT 0,
    accuracy        REAL    DEFAULT 0,
    avg_response_time REAL  DEFAULT 0,
    final_budget    REAL    DEFAULT 100,
    final_difficulty INTEGER DEFAULT 5
  )`);

  // ── Responses ─────────────────────────────────────────────
  db.run(`CREATE TABLE IF NOT EXISTS responses (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT,
    question        TEXT,
    selected_answer TEXT,
    correct_answer  TEXT,
    is_correct      INTEGER DEFAULT 0,
    confidence      INTEGER DEFAULT 50,
    response_time   REAL    DEFAULT 0,
    difficulty      INTEGER DEFAULT 5,
    topic           TEXT    DEFAULT 'General',
    content_type    TEXT    DEFAULT 'text',
    timestamp       TEXT    DEFAULT (datetime('now'))
  )`);

  // ── CV States ─────────────────────────────────────────────
  db.run(`CREATE TABLE IF NOT EXISTS cv_states (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT,
    state      TEXT    DEFAULT 'FOCUSED',
    blink_rate REAL    DEFAULT 0,
    gaze       TEXT    DEFAULT 'on_screen',
    emotion    TEXT    DEFAULT 'neutral',
    head_pose  TEXT    DEFAULT 'normal',
    timestamp  TEXT    DEFAULT (datetime('now'))
  )`);

  // ── Integrity Events ──────────────────────────────────────
  db.run(`CREATE TABLE IF NOT EXISTS integrity_events (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT,
    event_type TEXT,
    details    TEXT,
    timestamp  TEXT DEFAULT (datetime('now'))
  )`);

});

// ── Promise helpers ────────────────────────────────────────────
db.runQuery = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) reject(err);
      else     resolve({ lastID: this.lastID, changes: this.changes });
    });
  });

db.getAll = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else     resolve(rows || []);
    });
  });

db.getOne = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else     resolve(row || null);
    });
  });

module.exports = db;
