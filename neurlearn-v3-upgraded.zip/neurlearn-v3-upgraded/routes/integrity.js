// ── Integrity Routes ────────────────────────────────────────────
// POST /api/integrity/event  — frontend reports tab switch, paste etc.
// GET  /api/integrity/score  — get current integrity score

const express = require('express');
const db      = require('../config/database');
const { recordEvent, getIntegrity } = require('../modules/integrity');

const router = express.Router();

// POST /api/integrity/event
// Called by frontend when it detects: tab_switch, paste, copy, right_click
// Body: { session_id, event_type, details? }
router.post('/event', async (req, res) => {
  const {
    session_id = 'default',
    event_type,
    details    = '',
  } = req.body;

  const validEvents = ['tab_switch', 'paste', 'copy', 'right_click'];
  if (!event_type || !validEvents.includes(event_type)) {
    return res.status(400).json({
      error: `event_type must be one of: ${validEvents.join(', ')}`,
    });
  }

  try {
    // Save to DB
    await db.runQuery(
      `INSERT INTO integrity_events (session_id, event_type, details)
       VALUES (?, ?, ?)`,
      [session_id, event_type, details]
    );

    // Update integrity score
    const result = recordEvent(session_id, event_type, details);

    res.json({
      success: true,
      ...result,
    });

  } catch (error) {
    console.error('❌ Integrity event error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/integrity/score?session_id=xxx
router.get('/score', async (req, res) => {
  const session_id = req.query.session_id || 'default';
  try {
    const state  = getIntegrity(session_id);
    const events = await db.getAll(
      'SELECT * FROM integrity_events WHERE session_id = ? ORDER BY id DESC',
      [session_id]
    );
    res.json({
      session_id,
      integrity_score:     state.score,
      flags:               state.flags,
      verification_needed: state.score < 70,
      events,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
