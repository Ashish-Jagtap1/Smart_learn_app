// ── POST /api/cv/state ─────────────────────────────────────────
// Called every 5 seconds by Person 1's CV engine.
// Saves state, depletes cognitive budget, updates difficulty engine.
//
// Request:  { session_id, state, blink_rate?, gaze?, emotion?, head_pose? }
// Response: { success, state, budget }
//
// Valid states: FOCUSED | TIRED | FRUSTRATED | DISTRACTED | SLEEPING

const express = require('express');
const db      = require('../config/database');
const { depleteBudget, getBudget } = require('../modules/cognitiveBudget');
const { setCVState } = require('./answers');

const router      = express.Router();
const VALID_STATES = ['FOCUSED', 'TIRED', 'FRUSTRATED', 'DISTRACTED', 'SLEEPING'];

// POST /api/cv/state
router.post('/state', async (req, res) => {
  const {
    session_id = 'default',
    state      = 'FOCUSED',
    blink_rate = 0,
    gaze       = 'on_screen',
    emotion    = 'neutral',
    head_pose  = 'normal',
  } = req.body;

  // Sanitize state
  const cvState = VALID_STATES.includes(state) ? state : 'FOCUSED';

  try {
    // 1. Save CV reading to DB
    await db.runQuery(
      `INSERT INTO cv_states (session_id, state, blink_rate, gaze, emotion, head_pose)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [session_id, cvState, blink_rate, gaze, emotion, head_pose]
    );

    // 2. Deplete cognitive budget
    const newBudget = depleteBudget(session_id, cvState);

    // 3. Share CV state with answers.js (for difficulty engine)
    setCVState(session_id, cvState);

    console.log(`👁  CV: ${cvState} | budget: ${Math.round(newBudget)} | blink: ${blink_rate}/min | gaze: ${gaze}`);

    res.json({
      success: true,
      state:   cvState,
      budget:  Math.round(newBudget),
    });

  } catch (error) {
    console.error('❌ CV state error:', error.message);
    res.status(500).json({ error: 'Failed to save CV state', message: error.message });
  }
});

// GET /api/cv/history?session_id=xxx&limit=20
router.get('/history', async (req, res) => {
  const { session_id = 'default', limit = 20 } = req.query;
  try {
    const states = await db.getAll(
      `SELECT * FROM cv_states WHERE session_id = ? ORDER BY id DESC LIMIT ?`,
      [session_id, parseInt(limit)]
    );
    res.json({ states, total: states.length });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
