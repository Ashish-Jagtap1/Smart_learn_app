// ── Session Management ─────────────────────────────────────────
// POST /api/session/start  — begin new session, reset all state
// POST /api/session/end    — save final summary to DB
// GET  /api/session/history — all past sessions

const express = require('express');
const db      = require('../config/database');
const { resetBudget }     = require('../modules/cognitiveBudget');
const { resetDifficulty } = require('../modules/difficultyEngine');
const { resetIntegrity }  = require('../modules/integrity');

const router = express.Router();

// POST /api/session/start
router.post('/start', async (req, res) => {
  const {
    session_id = `session_${Date.now()}`,
    topic      = 'General',
  } = req.body;

  try {
    // Reset all in-memory state
    resetBudget(session_id);
    resetDifficulty(session_id);
    resetIntegrity(session_id);

    // Save to DB
    await db.runQuery(
      `INSERT OR REPLACE INTO sessions (session_id, topic, start_time)
       VALUES (?, ?, datetime('now'))`,
      [session_id, topic]
    );

    console.log(`🚀 Session started: ${session_id} | topic: ${topic}`);

    res.json({
      success:    true,
      session_id,
      topic,
      budget:     100,
      difficulty: 5,
      message:    `Session started! Ready to learn about "${topic}"`,
    });

  } catch (error) {
    console.error('❌ Session start error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// POST /api/session/end
router.post('/end', async (req, res) => {
  const { session_id = 'default' } = req.body;

  try {
    const responses = await db.getAll(
      'SELECT * FROM responses WHERE session_id = ?',
      [session_id]
    );

    const total    = responses.length;
    const correct  = responses.filter(r => r.is_correct).length;
    const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
    const avgTime  = total > 0
      ? Math.round(responses.reduce((s, r) => s + (r.response_time || 0), 0) / total * 10) / 10
      : 0;

    await db.runQuery(
      `UPDATE sessions
       SET end_time = datetime('now'), total_questions = ?, correct_answers = ?,
           accuracy = ?, avg_response_time = ?
       WHERE session_id = ?`,
      [total, correct, accuracy, avgTime, session_id]
    );

    console.log(`🏁 Session ended: ${session_id} | ${correct}/${total} (${accuracy}%)`);

    res.json({
      success:         true,
      session_id,
      total_questions: total,
      correct_answers: correct,
      accuracy,
      avg_response_time: avgTime,
      message: `Session complete! ${correct}/${total} correct (${accuracy}%)`,
    });

  } catch (error) {
    console.error('❌ Session end error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/session/history
router.get('/history', async (req, res) => {
  try {
    const sessions = await db.getAll(
      'SELECT * FROM sessions ORDER BY id DESC LIMIT 20'
    );
    res.json({ sessions, total: sessions.length });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
