// ── POST /api/questions ────────────────────────────────────────
// Generates MCQ questions using Groq AI (llama-3.3-70b)
// Difficulty = MIN(budget difficulty, performance difficulty)
//
// Request:  { topic, session_id, num_questions? }
// Response: { questions[], difficulty, budget, topic, total, session_id }

const express = require('express');
const Groq    = require('groq-sdk');
const { getBudget, getDifficultyFromBudget } = require('../modules/cognitiveBudget');
const { getDifficulty } = require('../modules/difficultyEngine');

const router = express.Router();
const groq   = new Groq({ apiKey: process.env.GROQ_API_KEY });

router.post('/', async (req, res) => {
  const {
    topic,
    session_id    = 'default',
    num_questions = 5,
  } = req.body;

  if (!topic) {
    return res.status(400).json({ error: 'Topic is required' });
  }

  try {
    // Get difficulty — lower of budget vs performance (be kind to student)
    const budget           = getBudget(session_id);
    const budgetDifficulty = getDifficultyFromBudget(budget);
    const perfDifficulty   = getDifficulty(session_id);
    const difficulty       = Math.min(budgetDifficulty, perfDifficulty);

    const diffDesc =
      difficulty <= 3 ? 'very easy — simple recall and basic facts' :
      difficulty <= 6 ? 'medium — understanding and application'    :
                        'hard — analysis, evaluation, critical thinking';

    const prompt = `You are a quiz generator for an adaptive learning platform.

Generate exactly ${num_questions} multiple choice questions about: "${topic}"
Difficulty: ${difficulty}/10 (${diffDesc})

STRICT RULES:
- Each question must have exactly 4 options labeled A, B, C, D
- Exactly ONE correct answer per question
- Options must be meaningfully different from each other
- Explanation must be 1-2 sentences only
- Questions must match the difficulty level strictly

CRITICAL: Return ONLY a raw JSON array. No markdown, no backticks, no commentary, no extra text before or after.

[
  {
    "question": "Your question text here?",
    "options": ["A) First option", "B) Second option", "C) Third option", "D) Fourth option"],
    "correct": "A",
    "explanation": "Why A is the correct answer in 1-2 sentences."
  }
]`;

    const completion = await groq.chat.completions.create({
      model:       'llama-3.3-70b-versatile',
      messages:    [{ role: 'user', content: prompt }],
      temperature: 0.7,
      max_tokens:  2000,
    });

    let rawText = completion.choices[0].message.content.trim();

    // Strip any markdown fences
    rawText = rawText.replace(/```json|```/g, '').trim();

    // Extract JSON array even if there's extra text
    const startIdx = rawText.indexOf('[');
    const endIdx   = rawText.lastIndexOf(']');
    if (startIdx !== -1 && endIdx !== -1) {
      rawText = rawText.substring(startIdx, endIdx + 1);
    }

    const questions = JSON.parse(rawText);

    if (!Array.isArray(questions) || questions.length === 0) {
      throw new Error('No questions returned from AI');
    }

    console.log(`✅ Questions: ${questions.length} on "${topic}" | difficulty: ${difficulty}/10 | budget: ${Math.round(budget)}`);

    res.json({
      questions,
      difficulty,
      budget:     Math.round(budget),
      topic,
      total:      questions.length,
      session_id,
    });

  } catch (error) {
    console.error('❌ Question generation error:', error.message);

    if (error instanceof SyntaxError) {
      return res.status(500).json({
        error:   'AI returned invalid JSON',
        message: 'Try again — the AI occasionally returns malformed responses',
      });
    }

    res.status(500).json({
      error:   'Failed to generate questions',
      message: error.message,
    });
  }
});

module.exports = router;
