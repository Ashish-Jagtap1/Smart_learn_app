// ── GET /api/status ────────────────────────────────────────────
// Returns ALL metrics for the frontend dashboard.
// This is the main polling endpoint — call every 5 seconds.
//
// Response: {
//   budget, difficulty, accuracy, total_questions,
//   cv_state, blink_rate, gaze, emotion,
//   fingerprint, matrix, suggestions, integrity,
//   streak, session_id
// }

const express = require('express');
const db      = require('../config/database');
const { getBudget }            = require('../modules/cognitiveBudget');
const { getDifficulty, getStreak } = require('../modules/difficultyEngine');
const { calculateFingerprint } = require('../modules/fingerprint');
const { calculateMatrix }      = require('../modules/matrix');
const { generateSuggestions }  = require('../modules/coach');
const { getIntegrity }         = require('../modules/integrity');

const router = express.Router();

// GET /api/status?session_id=xxx
router.get('/', async (req, res) => {
  const session_id = req.query.session_id || 'default';

  try {
    // Fetch all data in parallel
    const [responses, latestCV] = await Promise.all([
      db.getAll(
        'SELECT * FROM responses WHERE session_id = ? ORDER BY id ASC',
        [session_id]
      ),
      db.getOne(
        'SELECT * FROM cv_states WHERE session_id = ? ORDER BY id DESC LIMIT 1',
        [session_id]
      ),
    ]);

    // Core metrics
    const budget     = Math.round(getBudget(session_id));
    const difficulty = getDifficulty(session_id);
    const streak     = getStreak(session_id);

    // Session stats
    const total   = responses.length;
    const correct = responses.filter(r => r.is_correct).length;
    const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
    const avgTime  = total > 0
      ? Math.round(responses.reduce((s, r) => s + (r.response_time || 0), 0) / total * 10) / 10
      : 0;

    // Advanced features
    const fingerprint = calculateFingerprint(responses);
    const matrix      = calculateMatrix(responses);
    const integrity   = getIntegrity(session_id);

    // Coach suggestions
    const suggestions = generateSuggestions({
      budget,
      cvState:           latestCV?.state || 'FOCUSED',
      minutesSinceBreak: Math.min(total, 60),
      responses,
    });

    res.json({
      // ── Core ──────────────────────────────────────────
      budget,
      difficulty,
      accuracy,
      total_questions:   total,
      correct_answers:   correct,
      avg_response_time: avgTime,
      streak,

      // ── CV State (from Person 1) ───────────────────────
      cv_state:   latestCV?.state      || 'FOCUSED',
      blink_rate: latestCV?.blink_rate || 0,
      gaze:       latestCV?.gaze       || 'on_screen',
      emotion:    latestCV?.emotion    || 'neutral',
      head_pose:  latestCV?.head_pose  || 'normal',

      // ── Advanced Features ──────────────────────────────
      fingerprint,
      matrix,
      suggestions,

      // ── Integrity ─────────────────────────────────────
      integrity: {
        score:               integrity.score,
        flags:               integrity.flags,
        verification_needed: integrity.score < 70,
      },

      session_id,
      timestamp: new Date().toISOString(),
    });

  } catch (error) {
    console.error('❌ Status error:', error.message);
    res.status(500).json({ error: 'Failed to get status', message: error.message });
  }
});

// GET /api/status/fingerprint?session_id=xxx
router.get('/fingerprint', async (req, res) => {
  try {
    const responses = await db.getAll(
      'SELECT * FROM responses WHERE session_id = ?',
      [req.query.session_id || 'default']
    );
    res.json(calculateFingerprint(responses));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/status/matrix?session_id=xxx
router.get('/matrix', async (req, res) => {
  try {
    const responses = await db.getAll(
      'SELECT * FROM responses WHERE session_id = ?',
      [req.query.session_id || 'default']
    );
    res.json(calculateMatrix(responses));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/status/suggestions?session_id=xxx
router.get('/suggestions', async (req, res) => {
  try {
    const session_id = req.query.session_id || 'default';
    const [responses, latestCV] = await Promise.all([
      db.getAll('SELECT * FROM responses WHERE session_id = ?', [session_id]),
      db.getOne('SELECT * FROM cv_states WHERE session_id = ? ORDER BY id DESC LIMIT 1', [session_id]),
    ]);
    const suggestions = generateSuggestions({
      budget:            Math.round(getBudget(session_id)),
      cvState:           latestCV?.state || 'FOCUSED',
      minutesSinceBreak: Math.min(responses.length, 60),
      responses,
    });
    res.json({ suggestions });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
