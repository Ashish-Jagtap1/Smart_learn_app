// ── POST /api/answer ───────────────────────────────────────────
// Called after student submits each answer.
// Saves to DB, updates difficulty, checks integrity.
//
// Request:  { session_id, question, selected_answer, correct_answer,
//             is_correct, confidence, response_time, difficulty, topic, content_type }
// Response: { success, new_difficulty, budget, cv_state, integrity, streak }

const express  = require('express');
const db       = require('../config/database');
const { updateDifficulty, getStreak } = require('../modules/difficultyEngine');
const { getBudget }                   = require('../modules/cognitiveBudget');
const { checkIntegrity }              = require('../modules/integrity');

const router = express.Router();

// Shared CV state — updated by /api/cv/state every 5 seconds
const sessionCVStates = {};
const setCVState = (sessionId, state) => { sessionCVStates[sessionId] = state; };
const getCVState = (sessionId)        => sessionCVStates[sessionId] || 'FOCUSED';

router.post('/', async (req, res) => {
  const {
    session_id      = 'default',
    question,
    selected_answer,
    correct_answer,
    is_correct,
    confidence      = 50,
    response_time   = 15,
    difficulty      = 5,
    topic           = 'General',
    content_type    = 'text',
  } = req.body;

  // Validate required fields
  if (!question || selected_answer === undefined || is_correct === undefined) {
    return res.status(400).json({
      error: 'Missing required fields: question, selected_answer, is_correct',
    });
  }

  try {
    // 1. Save answer to database
    await db.runQuery(`
      INSERT INTO responses
        (session_id, question, selected_answer, correct_answer,
         is_correct, confidence, response_time, difficulty, topic, content_type)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      session_id,
      question,
      selected_answer,
      correct_answer,
      is_correct ? 1 : 0,
      confidence,
      response_time,
      difficulty,
      topic,
      content_type,
    ]);

    // 2. Update difficulty engine
    const cvState       = getCVState(session_id);
    const newDifficulty = updateDifficulty(session_id, is_correct, cvState);
    const budget        = Math.round(getBudget(session_id));
    const streak        = getStreak(session_id);

    // 3. Get last 10 answers for integrity check
    const recentAnswers = await db.getAll(
      `SELECT is_correct, response_time FROM responses
       WHERE session_id = ? ORDER BY id DESC LIMIT 10`,
      [session_id]
    );

    // 4. Anti-gaming check
    const integrity = checkIntegrity(
      session_id,
      { is_correct, response_time, difficulty },
      recentAnswers
    );

    console.log(`✅ Answer | correct:${is_correct} | difficulty:${newDifficulty} | budget:${budget} | cv:${cvState}`);

    res.json({
      success:        true,
      new_difficulty: newDifficulty,
      budget,
      cv_state:       cvState,
      streak,
      integrity,
    });

  } catch (error) {
    console.error('❌ Answer error:', error.message);
    res.status(500).json({ error: 'Failed to save answer', message: error.message });
  }
});

module.exports = router;
module.exports.setCVState = setCVState;
module.exports.getCVState = getCVState;
