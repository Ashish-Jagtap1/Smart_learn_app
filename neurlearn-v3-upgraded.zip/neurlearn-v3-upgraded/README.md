# NeurLearn Backend v3.0
Speed-adaptive EdTech platform — Person 2 (Backend)

## Setup

```bash
npm install
```

Create `.env` file:
```
GROQ_API_KEY=gsk_your_key_here
PORT=5000
```

Run:
```bash
npm run dev
```

---

## All API Endpoints

### Health Check
```
GET /
```

---

### Questions
```
POST /api/questions
Body: { topic, session_id, num_questions? }
Response: { questions[], difficulty, budget, topic, total }
```

---

### Submit Answer
```
POST /api/answer
Body: {
  session_id, question, selected_answer, correct_answer,
  is_correct, confidence (0-100), response_time (seconds),
  difficulty, topic, content_type
}
Response: { success, new_difficulty, budget, cv_state, streak, integrity }
```

---

### CV State (Person 1 sends this every 5 seconds)
```
POST /api/cv/state
Body: { session_id, state, blink_rate?, gaze?, emotion?, head_pose? }
State values: FOCUSED | TIRED | FRUSTRATED | DISTRACTED | SLEEPING
Response: { success, state, budget }

GET /api/cv/history?session_id=xxx
```

---

### Status Dashboard (poll every 5 seconds)
```
GET /api/status?session_id=xxx
Response: {
  budget, difficulty, accuracy, total_questions, correct_answers,
  avg_response_time, streak,
  cv_state, blink_rate, gaze, emotion, head_pose,
  fingerprint, matrix, suggestions, integrity
}

GET /api/status/fingerprint?session_id=xxx
GET /api/status/matrix?session_id=xxx
GET /api/status/suggestions?session_id=xxx
```

---

### Session
```
POST /api/session/start
Body: { session_id, topic }
Response: { success, session_id, topic, budget:100, difficulty:5 }

POST /api/session/end
Body: { session_id }
Response: { success, total_questions, correct_answers, accuracy }

GET /api/session/history
```

---

### Integrity
```
POST /api/integrity/event
Body: { session_id, event_type, details? }
event_type: tab_switch | paste | copy | right_click

GET /api/integrity/score?session_id=xxx
```

---

## Integration Guide for Frontend (Person 4)

1. Start session:      `POST /api/session/start`
2. Get questions:      `POST /api/questions`
3. After each answer:  `POST /api/answer`
4. Poll every 5s:      `GET /api/status`
5. End session:        `POST /api/session/end`
6. Report events:      `POST /api/integrity/event` (tab switch, paste)

## Integration Guide for CV Engine (Person 1)

Send CV state every 5 seconds:
```
POST /api/cv/state
{ session_id, state: "FOCUSED", blink_rate: 15, gaze: "on_screen", emotion: "neutral" }
```
